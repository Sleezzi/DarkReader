document.querySelector("a#install").innerHTML = "Thanks for download";
document.querySelector("a#install").removeAttribute("href");
document.querySelector("a#install").removeAttribute("target");
document.querySelector("a#install").style.cursor = "not-allowed";